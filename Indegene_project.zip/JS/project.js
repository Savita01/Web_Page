document.addEventListener("DOMContentLoaded", function (){
    document.getElementById("mainbutton").addEventListener("click",function(){
        var menuBox=document.getElementById('menulist');
        if(menuBox.style.display=="none")
        {
           menuBox.style.display="block";
        } 
        else
        {
           menuBox.style.display="none";
        }       
      })
});
